package com.mich.captain.facialrecognition;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.Gravity;
import android.widget.Toast;

import java.io.File;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import static com.mich.captain.facialrecognition.ComputationMath.*;

public class Eigenfaces extends AsyncTask <Context, Integer, Boolean> {

    private EigenfacesResultTask mCallback = null;

    private Database db = null;
    private int imageSize;
    private double M;
    ProgressDialog myProgress = null;
    private Context mContext;


    public Eigenfaces(Context _context, int imageSize, EigenfacesResultTask myEFRT) {

        mContext = _context;

        this.imageSize = imageSize;
        this.M = 0;                        // number of database images
        this.mCallback = myEFRT;

        /* myProgress = new ProgressDialog(context);
        myProgress.setTitle("Processing Data");
        myProgress.setMessage("Please wait...");
        myProgress.setMax(100);
        myProgress.setIndeterminate(false); */
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        CharSequence text = "Start Eigenfaces Computation Process";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(mContext, text, duration);
        toast.setGravity(Gravity.BOTTOM| Gravity.CENTER, 0, 200);
        toast.show();
    }

    @Override
    protected Boolean doInBackground(Context... params) {

        List<double[]> s = new ArrayList<>(); // to store all the transposed images
        double[] face_average = null; // face average array
        double[][] s_less_face_average = null; // image less face average matrix
        double[][] s_less_face_average_transpose = null; // image less face average matrix
        double[][] covarianceMatrix = null; // A^T * A
        double[][] eigenvectorsMatrix_temp = null; // the eigenvectors matrix
        double[][] eigenvaluesMatrix_temp = null; // the eigenvalues matrix
        double[][] eigenvectorsMatrix_transpose = null;
        double[][] eigenvectorsMatrix = null; // the eigenvectors matrix final
        //double lambda = 0.95; // threshold value to reduce the autospace
        double[][] projection_coefficients;
        double[][] face_projection_matrix;
        double[][] face_projection_space = null; // the linear combination of face_less_face_average and the eigenvectors


        String folder_path = Environment.getExternalStorageDirectory() + "/APP/DB_bw/";
        String image_path = null;
        File directory = new File(folder_path);
        File[] files = directory.listFiles();
        M = files.length;

        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                image_path = folder_path + files[i].getName().toString();
                Bitmap image = Image.getImage(image_path);

                // transpose the image into a column vector
                double[] image_column = Image.getColumnVectorOfImage(image, 256 * 256);
                //image_column = multiplyArrayForANumber(image_column, 0.00426299045599151);

                // create the set S
                s.add(image_column);
            }

            //testEigenfacesCalculation();

            /** calculate average face */
            face_average = calculateFaceAverage(256, s, M);
            //saveToDatabaseFM(face_average);

            /** subtract face average to each image => A */
            s_less_face_average_transpose = subtractFaceAverageToAnImage(s , face_average);
            s_less_face_average = transposeMatrix(s_less_face_average_transpose);

            /** calculate covariance matrix => A x A^T */
            covarianceMatrix = productOfMatrixAndMatrixTranspose(s_less_face_average);

            /** calculate the eigenvcetors and eigenvalues of A x A^T */
            eigenvaluesMatrix_temp = getEigenvaluesMatrix(covarianceMatrix);
            eigenvectorsMatrix_temp = getEigenvectorsMatrix(covarianceMatrix);

            /** calculate Au */
            eigenvectorsMatrix_transpose = productOfTwoMatrix(s_less_face_average, eigenvectorsMatrix_temp);
            eigenvectorsMatrix = multiplyMatrixForANumber(transposeMatrix(eigenvectorsMatrix_transpose), 1/M);

            /** compute face projection */
            projection_coefficients = calculateProjectionCoefficients(transposeMatrix(s_less_face_average), eigenvectorsMatrix);
            face_projection_matrix = calculateEigenfacesProjection(transposeMatrix(s_less_face_average), eigenvectorsMatrix, projection_coefficients);
            //face_projection_space = productOfTwoMatrix(eigenvectorsMatrix_transpose,  transposeMatrix(s_less_face_average));
            //testEigenfacesCalculation();

            // save it in db
            saveToDatabase(face_projection_matrix);

            mCallback.onTaskComplete(face_average, eigenvectorsMatrix, projection_coefficients, M);
            return true;
        }

        return false;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        myProgress.setProgress(values[0]);
    }

    @Override
    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);

        if(result==true) {
            CharSequence text = "Database Succesfull Created";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(mContext, text, duration);
            toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
            toast.show();
        }
        else
        {
            CharSequence text = "Database Not Created";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(mContext, text, duration);
            toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
            toast.show();
        }

    }


    private static void saveToDatabase(double[][] matrixOfImages) {
        Bitmap face_projection = null;
        Database db = null;
        db = new Database();

        double[] column = new double[matrixOfImages[0].length]; // Here I assume a rectangular 2D array!
        int index = matrixOfImages.length;

        int[] column_final = new int[column.length];

        for (int i = 0; i < index; i++) {

            for (int j = 0; j < column.length; j++) {
                column[j] = matrixOfImages[i][j];
            }

            double max_value = getMaxArrayValue(column);
            double min_value = getMinArrayValue(column);

            double scalar_coefficient = 255 / max_value;

            for (int k = 0; k < column.length; k++) {
                column[k] = column[k];
                column[k] = scalar_coefficient * column[k];
            }

            // cast the Array to int Array
            for (int m = 0; m < column_final.length; m++) {

                int color = ((int) column[m] & 0xff) << 24 |
                        ((int) column[m] & 0xff) << 16 |
                        ((int) column[m] & 0xff) << 8 |
                        ((int) column[m] & 0xff);

                column_final[m] = color;

            }

            face_projection = Bitmap.createBitmap(column_final, 256, 256, Bitmap.Config.ARGB_8888);

            db.createTrainingDatabase(face_projection, i);
        }
    }


    private static void saveToDatabaseFM(double[] column) {

        Bitmap face_projection = null;
        Database db = null;
        db = new Database();

        int[] column_final = new int[column.length];

        // cast the Array to int Array
        for (int m = 0; m < column_final.length; m++) {

            int color = ((int) column[m] & 0xff) << 24 |
                    ((int) column[m] & 0xff) << 16 |
                    ((int) column[m] & 0xff) << 8 |
                    ((int) column[m] & 0xff);

            column_final[m] = color;
        }

        face_projection = Bitmap.createBitmap(column_final, 256, 256, Bitmap.Config.ARGB_8888);
        db.createTrainingDatabase(face_projection, 1);
    }



}
