package com.mich.captain.facialrecognition;

public interface EigenfacesResultTask {

    void onTaskComplete(double[] faceAverageResult, double[][] eigenvectorsMatrixResult, double[][] projectionCoefficients, double numberOfPics);
}
