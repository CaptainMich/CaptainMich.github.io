package com.mich.captain.facialrecognition;

import java.util.List;

import Jama.EigenvalueDecomposition;
import Jama.Matrix;

import static Jama.Matrix.constructWithCopy;

public class ComputationMath {


    public static double[] calculateFaceAverage(int imageSize, List<double[]> set, double numberOfPicture) {

        double[] psi = new double[imageSize * imageSize];

        for (int k = 0; k < set.size(); k++){
            for (int j = 0; j < imageSize * imageSize; j++) {
                psi[j] += (1/(numberOfPicture)) * set.get(k)[j];
            }
        }

        return psi;
    }


    public static double[][] subtractFaceAverageToAnImage(List<double[]> set, double[] phi) {

        double[][] set_less_face_average = new double[set.size()][set.get(0).length];

        for (int i = 0; i < set.size(); i++) {
            for (int j = 0; j < set.get(i).length; j++) {
                set_less_face_average[i][j] = set.get(i)[j] - phi[j];
            }
        }

        return set_less_face_average;
    }


    public static double[][] transposeMatrix(double[][] m) {

        double[][] temp = new double[m[0].length][m.length];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                temp[j][i] = m[i][j];
            }
        }

        return temp;
    }

    public static double productOfTwoArray(double[] a1, double[] a2){

        double aResult = 0;

        for (int i = 0 ; i < a1.length ; i++)
        {
            aResult += a1[i] * a2[i];
        }

        return aResult;
    }


    public static double[][] productOfTwoMatrix(double[][] m1, double[][] m2) {

        int m1_col = m1[0].length;              // m1 columns length
        int m1_row = m1.length;                 // m1 row length
        int m2_col = m2[0].length;              // m2 columns length
        int m2_row = m2.length;                 // m2 row length

        double[][] mResult = new double[m1_row][m2_col];

        // check if it is possible to do matrix multiplication
        if (m1_col != m2_row) {
            return null;
        } else {

            for (int i = 0; i < m1_row; i++) {
                for (int j = 0; j < m2_col; j++) {
                    for (int k = 0; k < m1_col; k++) {
                        mResult[i][j] += m1[i][k] * m2[k][j];
                    }
                }
            }
        }

        return mResult;
    }

    public static double[][] multiplyMatrixForANumber(double[][] m, double p) {

        int m_col = m[0].length;              // m1 columns length
        int m_row = m.length;                 // m1 row length

        double[][] mResult = new double[m_row][m_col];

        for (int i = 0; i < m_row; i++) {
            for (int j = 0; j < m_col; j++) {

                mResult[i][j] = p * m[i][j];
            }
        }

        return  mResult;
    }



    public static double[] multiplyArrayForANumber(double[] m, double p) {

        double[] mResult = new double[m.length];

        for (int i = 0; i < m.length; i++) {
            mResult[i] = p * m[i];
        }

        return  mResult;
    }

    public static double[] convert2DMatrixToSingleArray(double[][] m)
    {
        double aResult[] = new double[m.length * m[0].length];

        for(int i = 0; i < m.length; i++)
        {
            double[] row = m[i];
            for(int j = 0; j < row.length; j++)
            {
                double number = m[i][j];
                aResult[i * row.length + j] = number;
            }
        }

        return aResult;
    }

    public static double[][] convertSingleArrayTo2DMatrix(double[] m, int row, int column)
    {
        double mResult[][] = new double[row][column];

        for(int i=0; i < row; i++)
        {
            for(int j=0; j < column; j++)
            {
                mResult[i][j] = m[j];
            }
        }

        return mResult;
    }

    public static double getMaxArrayValue(double[] inputArray){
        double maxValue = inputArray[0];
        for(int i=1;i < inputArray.length;i++){
            if(inputArray[i] > maxValue){
                maxValue = inputArray[i];
            }
        }
        return maxValue;
    }

    public static double getMinArrayValue(double[] inputArray){
        double minValue = inputArray[0];
        for(int i=1;i<inputArray.length;i++){
            if(inputArray[i] < minValue){
                minValue = inputArray[i];
            }
        }
        return minValue;
    }

    public static double[][] productOfMatrixAndMatrixTranspose(double[][] set) {

        double[][] covarianceMatrix = null;

        double[][] set_transposed = transposeMatrix(set);

        covarianceMatrix= (productOfTwoMatrix(set_transposed,set));

        return covarianceMatrix;
    }


    // To see how this work
    // https://github.com/fiji/Jama/blob/master/src/main/java/Jama/EigenvalueDecomposition.java
    public static double[][] getEigenvaluesMatrix(double[][] m )
    {
        // construct a matrix from a copy of a 2-D array
        Matrix A = constructWithCopy(m);
        EigenvalueDecomposition e = A.eig();

        // the block diagonal eigenvalues matrix
        Matrix diagonal_eigenvalues_matrix = e.getD();

        double temp_eigenvalues[][] = diagonal_eigenvalues_matrix.getArray();

        return temp_eigenvalues;

    }

    public static double[][] getEigenvectorsMatrix(double[][] m )
    {
        // construct a matrix from a copy of a 2-D array
        Matrix A = constructWithCopy(m);

        EigenvalueDecomposition e = A.eig();

        // the eigenvector matrix
        Matrix eigenvectors_matrix = e.getV();

        double temp_eigenvectors[][] = eigenvectors_matrix.getArray();

        return temp_eigenvectors;

    }

    /**
     // sort an eigenvectors matrix based on its corresponding eigenvalues matrix
     // d = eigenvalues_matrix
     // v = eigenvectors_matrix
     public double[][] calculateSortedEigenvectorsMatrix(double[][] d, double[][] v ){


     List<EigenvectorsMatrixSorted> eigenvectorSorted = new ArrayList<EigenvectorsMatrixSorted>();

     for(int i = 0; i < diagonal_eigenvalues_matrix.getColumnDimension(); i++)
     {
     EigenvectorsMatrixSorted eigenvectorsSorted = new EigenvectorsMatrixSorted();
     eigenvectorsSorted.eigenvalue = d[i][i];
     eigenvectorsSorted.eigenvectors = v;

     eigenvectorSorted.add(eigenvectorsSorted);
     }

     Collections.sort(eigenvectorSorted, eigenvaluesComparator);

     double[][] temp_eigenvectors_sorted = null;

     for(int i = 0; i < diagonal_eigenvalues_matrix.getColumnDimension(); i++) {
     temp_eigenvectors_sorted = eigenvectorSorted.get(i).eigenvectors;
     }

     return temp_eigenvectors_sorted;
     }

     public static class EigenvectorsMatrixSorted
     {
     public double eigenvalue;
     public double[][] eigenvectors;
     }

     private static Comparator<EigenvectorsMatrixSorted> eigenvaluesComparator = new Comparator<EigenvectorsMatrixSorted>()
     {

     @Override
     public int compare(EigenvectorsMatrixSorted lhs, EigenvectorsMatrixSorted rhs){
     // sorted
     return (lhs.eigenvalue < rhs.eigenvalue ? 1 : (lhs.eigenvalue == rhs.eigenvalue ? 0 : -1));
     }
     }; **/

    // m1 : Image less face average matrix
    // m2 : eigenVectors matrix
    public static double[][] calculateProjectionCoefficients(double[][] m1, double[][] m2){

        int m1_col = m1[0].length;              // m1 columns length
        int m1_row = m1.length;                 // m1 row length
        int m2_col = m2[0].length;              // m2 columns length
        int m2_row = m2.length;                 // m2 row length

        double[][] coefficients = new double[m1_row][m2_row];
        double[] phi = new double[m1_col];
        double[] u = new double[m2_col];

        for (int i = 0; i < m1_row; i++) {
            for (int p = 0; p < m1_col; p++) {

                // temp value for phi[i]; each time one row is stored
                phi[p] = m1[i][p];
            }

            for(int j=0; j < m2_row; j++) {
                for(int k=0; k < m2_col; k++){

                    // temp value for
                    u[k] = m2[j][k];
                }

                coefficients[i][j] = productOfTwoArray(u, phi);
            }
        }

        coefficients = transposeMatrix(coefficients);
        return coefficients;
    }

    public static double[][] calculateEigenfacesProjection(double[][] m1, double[][] m2, double[][] coefficients){

        int m1_col = m1[0].length;              // m1 columns length
        int m1_row = m1.length;                 // m1 row length

        double[][] result = new double[m1_row][m1_col];
        result = productOfTwoMatrix(coefficients, m2);

        return result;
    }


    public static double[] calculateEuclideanDistance(double[] a1, double[] a2){

        double[] aResult = new double[a1.length];

        for (int i = 0 ; i < a1.length ; i++)
        {
            aResult[i] = Math.pow(Math.abs(a1[i] - a2[i]), 2);
        }

        return aResult;
    }

    /* public static double checkValue(double min_value)
    {
        double result = 0;

        if(min_value < (Math.pow(10, 10)))
            result = min_value / (Math.pow(10, 7));

        if(min_value > (Math.pow(10, 10)))
            result = min_value / (Math.pow(10, 8));

        if(min_value > (Math.pow(10, 11)))
            result = min_value / (Math.pow(10, 9));

        if(min_value > (Math.pow(10, 12)))
            result = min_value / (Math.pow(10, 10));

        if(min_value > (Math.pow(10, 13)))
            result = min_value / (Math.pow(10, 11));

        if(min_value > (Math.pow(10, 14)))
            result = min_value / (Math.pow(10, 12));

        if(min_value > (Math.pow(10, 15)))
            result = min_value / (Math.pow(10, 13));

        return result;
    }

    public static void testEigenfacesCalculation()
    {
        double[][] m1 = new double[2][2];
        double[][] m2 = new double[2][2];

        double[] a1 = new double[4];
        double[] a2 = new double[4];

        double result1 = 0;
        double[][] result = new double[2][2];

        m1[0][0] = 4;
        m1[0][1] = 5;
        m1[1][0] = 6;
        m1[1][1] = 7;

        m2[0][0] = 1;
        m2[0][1] = 2;
        m2[1][0] = 3;
        m2[1][1] = 4;

        a1[0] = 1;
        a1[1] = 2;
        a1[2] = 3;
        a1[3] = 4;

        a2[0] = 4;
        a2[1] = 5;
        a2[2] = 6;
        a2[3] = 7;

        result1 = productOfTwoArray(a1, a2);
        result = productOfTwoMatrix(m1,m2);
        int x = 0;

    }

        public static double[][] calculateEigenfacesProjection(double[][] m1, double[][] m2){

        int m1_col = m1[0].length;              // m1 columns length
        int m1_row = m1.length;                 // m1 row length
        int m2_col = m2[0].length;              // m2 columns length
        int m2_row = m2.length;                 // m2 row length

        double[][] coefficients = new double[m1_row][m2_row];
        double[][] result = new double[m1_row][m1_col];
        double[] phi = new double[m1_col];
        double[] u = new double[m2_col];

        for (int i = 0; i < m1_row; i++) {
            for (int p = 0; p < m1_col; p++) {

                // temp value for phi[i]; each time one row is stored
                phi[p] = m1[i][p];
            }

            for(int j=0; j < m2_row; j++) {
                for(int k=0; k < m2_col; k++){

                    // temp value for
                    u[k] = m2[j][k];
                }

                coefficients[i][j] = productOfTwoArray(u, phi);
            }
        }

        coefficients = transposeMatrix(coefficients);
        result = productOfTwoMatrix(coefficients, m2);
        return result;
    }*/
}

