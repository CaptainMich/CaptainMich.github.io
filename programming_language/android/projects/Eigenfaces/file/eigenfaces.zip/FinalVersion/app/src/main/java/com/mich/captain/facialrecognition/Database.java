package com.mich.captain.facialrecognition;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Database {

    private String DEFAULT_APP_IMAGEDATA_DIRECTORY;
    private String lastImagePath = "";


    /**
     * Returns the String path of the last saved image
     */
    public String getSavedImagePath() {
        return lastImagePath;
    }

    public boolean putImageWithFullPath(String fullPath, Bitmap theBitmap) {
        return !(fullPath == null || theBitmap == null) && saveBitmap(fullPath, theBitmap);
    }

    public String setupFullPath(String imageName, String path) {
        File mFolder = new File(Environment.getExternalStorageDirectory() + path);

        if (isExternalStorageReadable() && isExternalStorageWritable() && !mFolder.exists()) {
            if (!mFolder.mkdirs()) {
                Log.e("ERROR", "Failed to setup folder");
                return "";
            }
        }

        return mFolder.getPath() + '/' + imageName;
    }

    /**
     * Check if external storage is writable or not
     */
    public static boolean isExternalStorageWritable() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    /**
     * Check if external storage is readable or not
     */
    public static boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
    }

    /**
     * Saves the Bitmap as a PNG file at path 'fullPath'
     */
    public boolean saveBitmap(String fullPath, Bitmap bitmap) {
        if (fullPath == null || bitmap == null)
            return false;

        boolean fileCreated = false;
        boolean bitmapCompressed = false;
        boolean streamClosed = false;

        File imageFile = new File(fullPath);

        if (imageFile.exists())
            if (!imageFile.delete())
                return false;

        try {
            fileCreated = imageFile.createNewFile();

        } catch (IOException e) {
            e.printStackTrace();
        }

        FileOutputStream out = null;
        try {
            out = new FileOutputStream(imageFile);
            bitmapCompressed = bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);

        } catch (Exception e) {
            e.printStackTrace();
            bitmapCompressed = false;

        } finally {
            if (out != null) {
                try {
                    out.flush();
                    out.close();
                    streamClosed = true;

                } catch (IOException e) {
                    e.printStackTrace();
                    streamClosed = false;
                }
            }
        }

        return (fileCreated && bitmapCompressed && streamClosed);
    }


    public void createDatabase() {

        String folder_path = Environment.getExternalStorageDirectory() + "/APP/DB_colors/";
        String image_path = null;
        File directory = new File(folder_path);
        File[] files = directory.listFiles();

        //Log.d("Files", "Size: "+ files.length);

        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                image_path = folder_path + files[i].getName().toString();
                Bitmap temp = Image.getImage(image_path);
                Bitmap temp_bw = Image.createGrayScale(temp);
                Bitmap resized_temp = Image.resizeImage(temp_bw);
                putImageWithFullPath(setupFullPath(files[i].getName().toString().replace(".jpeg", "") + "_bw.png", "/APP/DB_bw"), resized_temp);
            }
        }
    }


    public void createTrainingDatabase(Bitmap src, int numberOfImage) {

        putImageWithFullPath(setupFullPath("image_" + String.valueOf(numberOfImage) + "_eigen.png", "/APP/DB_Training"), src);

    }
}


