package com.mich.captain.facialrecognition;

public interface FacialRecognitionResultTask {
}
