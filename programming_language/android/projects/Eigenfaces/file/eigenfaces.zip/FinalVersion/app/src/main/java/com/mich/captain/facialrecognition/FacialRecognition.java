package com.mich.captain.facialrecognition;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.Gravity;
import android.widget.Toast;

import static com.mich.captain.facialrecognition.ComputationMath.*;


public class FacialRecognition extends AsyncTask<Context, Integer, Boolean> {

    private FacialRecognitionResultTask mCallback = null;
    private Database db ;

    ProgressDialog myProgress = null;
    private Context mContext;
    private double threshold;
    private Bitmap input_pic;
    private int M;
    private double epsilon;
    private double[] epsilon_squared;
    private double[] face_average;
    private double[] image_less_face_average;
    private double[][] eigenvectors_matrix;
    private double[] projection_coefficients;
    private double[][] projection_coefficients_db;

    public FacialRecognition(Context _context, Bitmap pic, Database db, double[] faceAverage, double[][] eigenvectorsMatrix, double[][] projectionCoefficientsDB, double thresholdValue,
                             FacialRecognitionResultTask myFRRT)
    {

        mContext = _context;

        //this.mCallback = myFCRT;
        this.M = 25;
        this.db = db;
        this.input_pic = pic;
        this.face_average = faceAverage;
        this.eigenvectors_matrix = eigenvectorsMatrix;
        this.threshold = thresholdValue;
        this.projection_coefficients_db = projectionCoefficientsDB;

        /* myProgress = new ProgressDialog(context);
        myProgress.setTitle("Processing Data");
        myProgress.setMessage("Please wait...");
        myProgress.setMax(100);
        myProgress.setIndeterminate(false); */
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        CharSequence text = "Start Facial Recognition Process";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(mContext, text, duration);
        toast.setGravity(Gravity.BOTTOM| Gravity.CENTER, 0, 200);
        toast.show();
    }

    @Override
    protected Boolean doInBackground(Context... params) {

        projection_coefficients = new double[M];
        epsilon_squared = new double[M];

        // transpose the image into a column vector (delta)
        double[] image_column = Image.getColumnVectorOfImage(input_pic, 256 * 256);
        image_less_face_average = new double[image_column.length];

        // subtract the face average to the image
        for (int i = 0; i < image_column.length; i++) {
            image_less_face_average[i] = image_column[i] - face_average[i];
        }

        /**double[][] m1 = convertSingleArrayTo2DMatrix(image_less_face_average, 256);
        double[][] m2 = (transposeMatrix(eigenvectors_matrix));
        projection_coefficients = productOfTwoMatrix(m1, m2);
        **/

        for(int i=0; i < M; i++)
        {
            projection_coefficients[i] = productOfTwoArray(eigenvectors_matrix[i] ,image_less_face_average);
        }

        for(int k=0; k < M; k++)
        {
            epsilon_squared =  calculateEuclideanDistance(projection_coefficients, projection_coefficients_db[k]);
        }

        epsilon = getMinArrayValue(epsilon_squared) / (Math.pow(10, 9));


        if (epsilon > threshold)
            return false;
        else
            return true;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        myProgress.setProgress(values[0]);
    }

    @Override
    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);

        if(result==true) {
            CharSequence text = "Your face match with the db. UNLOCK!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(mContext, text, duration);
            toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
            toast.show();
        }
        else
        {
            CharSequence text = "Your face doesn't match with the db. Still LOCK. Try again.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(mContext, text, duration);
            toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
            toast.show();
        }

    }

    /** private double[] subtractFaceAverageToAnImage(double[] image, double[] face) {

     // return set_less_face_average;
     return
     }
     */

}


