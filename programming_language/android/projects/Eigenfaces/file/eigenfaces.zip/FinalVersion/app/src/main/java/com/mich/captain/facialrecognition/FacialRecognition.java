package com.mich.captain.facialrecognition;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.Gravity;
import android.widget.Toast;

import java.io.File;

import static com.mich.captain.facialrecognition.ComputationMath.*;


public class FacialRecognition extends AsyncTask<Context, Integer, Boolean> {

    private FacialRecognitionResultTask mCallback = null;
    private Database db ;

    ProgressDialog myProgress = null;
    private Context mContext;
    private double threshold_min = 0;
    private double threshold_max;
    private boolean flag = false;
    private Bitmap input_pic;
    private Bitmap input_pic_bw;
    private Bitmap input_pic_bw_resized;
    private int M;
    private double epsilon;
    private double min_epsilon_temp;
    private double min_epsilon = Double.MAX_VALUE;
    private double[][] epsilon_squared;
    private double[] face_average;
    private double[] image_less_face_average;
    private double[][] eigenvectors_matrix;
    private double[] projection_coefficients;
    private double[][] projection_coefficients_db;

    public FacialRecognition(Context _context, Bitmap pic, Database db, double[] faceAverage, double[][] eigenvectorsMatrix,
                             double[][] projectionCoefficientsDB, double numberOfPics, double thresholdValue,
                             FacialRecognitionResultTask myFRRT)
    {

        mContext = _context;

        //this.mCallback = myFCRT;
        this.M = (int)numberOfPics;
        this.db = db;
        this.input_pic = pic;
        this.face_average = faceAverage;
        this.eigenvectors_matrix = eigenvectorsMatrix;
        this.threshold_max = thresholdValue;
        this.projection_coefficients_db = projectionCoefficientsDB;

        /* myProgress = new ProgressDialog(context);
        myProgress.setTitle("Processing Data");
        myProgress.setMessage("Please wait...");
        myProgress.setMax(100);
        myProgress.setIndeterminate(false); */
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        CharSequence text = "Start Facial Recognition Process";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(mContext, text, duration);
        toast.setGravity(Gravity.BOTTOM| Gravity.CENTER, 0, 200);
        toast.show();
    }

    @Override
    protected Boolean doInBackground(Context... params) {

        projection_coefficients = new double[M];

        String folder_path = Environment.getExternalStorageDirectory() + "/APP/TestImage/";
        String filename = null;
        File directory = new File(folder_path);

        for (File f : directory.listFiles()) {
            if (f.isFile())
                filename = f.getName();
        }

        if(threshold_max == 0){
            flag = true;
            return false;
        }

        // transpose the image into a column vector (delta)

        if ("check_image.jpg".equals(filename)) {
            input_pic = Image.rotateImage(input_pic, 270);
        }
        input_pic_bw = Image.createGrayScale(input_pic);
        input_pic_bw_resized = Image.resizeImage(input_pic_bw);
        double[] image_column = Image.getColumnVectorOfImage(input_pic_bw_resized, 256 * 256);
        image_less_face_average = new double[image_column.length];

        // subtract the face average to the image
        for (int i = 0; i < image_column.length; i++) {
            image_less_face_average[i] = image_column[i] - face_average[i];
        }

        /**double[][] m1 = convertSingleArrayTo2DMatrix(image_less_face_average, 256);
        double[][] m2 = (transposeMatrix(eigenvectors_matrix));
        projection_coefficients = productOfTwoMatrix(m1, m2);
        **/

        for(int i=0; i < M; i++)
        {
            projection_coefficients[i] = productOfTwoArray(eigenvectors_matrix[i] ,image_less_face_average);
        }

        epsilon_squared = new double[M][M];

        for(int k=0; k < M; k++)
        {
            epsilon_squared[k] =  calculateEuclideanDistance(projection_coefficients, projection_coefficients_db[k]);
            min_epsilon_temp = getMinArrayValue(epsilon_squared[k]);

            if(min_epsilon_temp < min_epsilon)
                min_epsilon = min_epsilon_temp;

        }

        //epsilon = checkValue(min_epsilon);
        epsilon = min_epsilon * Math.pow(10, 20);

        if (epsilon > threshold_min && epsilon < threshold_max)
            return true;
        else
            return false;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        myProgress.setProgress(values[0]);
    }

    @Override
    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);

        if(result==true) {
            CharSequence text = "Your face match with the db. UNLOCK!\n" + "\t\t\t\t\t\t\t\t\t\t Epsilon: " + (int)epsilon;
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(mContext, text, duration);
            toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
            toast.show();
        }
        else
        {
            if (flag == true) {
                CharSequence text = "Please select a valid SeekBar Value";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(mContext, text, duration);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
                toast.show();
            }
            else{

                CharSequence text = "Your face doesn't match with the db. Still LOCK. Try again.\n" + "\t\t\t\t\t\t\t\t\t\t Epsilon: " + (int)epsilon;
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(mContext, text, duration);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER, 0, 200);
                toast.show();
            }
        }

    }
}


