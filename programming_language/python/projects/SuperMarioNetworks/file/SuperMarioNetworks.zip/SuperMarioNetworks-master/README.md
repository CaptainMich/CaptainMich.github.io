# SuperMarioNetworks

This program take in input an IP Address and its mask, besides the number of subnet and their respectively numbers of address and return all the subnet with:
  - Network Address
  - Broadcast Address 
  - Host Range 
  - Subnet Mask 

______________________________________________________________________________________________________________________________

#### How does it work on phone?

1. Download SuperMarioNetworks folder
2. Download the [ipaddress module](https://github.com/python/cpython/blob/3.6/Lib/ipaddress.py) and save it on the same folder
3. Download from the app store [QPython3 App](https://play.google.com/store/apps/details?id=org.qpython.qpy3&hl=it) 
4. Open QPython3 App &rarr; Click on Editor &rarr; Browse and Open your file(5) &rarr; Press play to open(3) and enjoy your app!  
  
  ![alt text](http://wiki.qpython.org/media/wiki/images/15/886636f2625e995cd9693b63237ab72a/qpython-05.png)
