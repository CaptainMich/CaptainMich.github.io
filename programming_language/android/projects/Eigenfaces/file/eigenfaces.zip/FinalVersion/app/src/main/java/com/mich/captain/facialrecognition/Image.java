package com.mich.captain.facialrecognition;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;


public class Image {

    private static final String TAG="Image";


    public static  Bitmap resizeImage(Bitmap src){
        if(src!=null)
            return Bitmap.createScaledBitmap(src, 256, 256, true);
        else
            Log.e(TAG,"Error, file don't exist");
        return null;
    }

    public static Bitmap createGrayScale(Bitmap src){

        int width = src.getWidth();
        int height = src.getHeight();

        Bitmap dest = Bitmap.createBitmap(width, height,
                Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(dest);
        Paint paint = new Paint();
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.setSaturation(0); //value of 0 maps the color to gray-scale
        ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrix);
        paint.setColorFilter(filter);
        canvas.drawBitmap(src, 0, 0, paint);

        return dest;
    }


    public static double[] getColumnVectorOfImage(Bitmap src, int imageSize){

        Bitmap bitmap = src; // assign your bitmap here
        int pixelCount = 0;
        double[] bitmap_column = new double[imageSize];

        for (int y = 0; y < bitmap.getHeight(); y++)
        {
            for (int x = 0; x < bitmap.getWidth(); x++)
            {
                int c = bitmap.getPixel(x,y);           // the value returned is in two's complement so negative is OK
                int A = (c >> 24) & 0xff;
                int R = (c>> 16) & 0xff;
                int G = (c >>  8) & 0xff;
                int B = (c      ) & 0xff;

                // int color = (A+R+G+B) / 4;
                double color = 0.2989 * R + 0.5870 * G + 0.1140 * B;
                bitmap_column[pixelCount] = color;
                pixelCount++;
            }
        }

        return bitmap_column;
    }


    public static void rotateImage(Context context, float angle){

        Database db = null;
        Bitmap image = null;
        Matrix matrix = new Matrix();

        try{

            String picturePath = Environment.getExternalStorageDirectory()+"/APP/check_image.jpg";
            image = BitmapFactory.decodeFile(picturePath);

            matrix.setRotate(angle);

            Bitmap rotatedBitmap = Bitmap.createBitmap(image, 0,0, image.getWidth(), image.getHeight(), matrix, true);

            db = new Database();
            db.saveBitmap(picturePath, rotatedBitmap);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context,"An error as occurred", Toast.LENGTH_SHORT).show();
        }
    }


    /**
     * Decodes the Bitmap from 'path' and returns it
     */
    public static Bitmap getImage(String path) {
        Bitmap bitmapFromPath = null;
        try {
            bitmapFromPath = BitmapFactory.decodeFile(path);

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }

        return bitmapFromPath;
    }

}


